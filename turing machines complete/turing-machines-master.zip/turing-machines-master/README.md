# Turing Machines in JFLAP 8.1
Implementation of Turing Machines in jFlap 8.1 for the "Computability and Complexity" exam
